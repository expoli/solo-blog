title: Windows 开机自启动特定虚拟机
date: '2019-08-15 17:18:51'
updated: '2019-08-15 18:54:53'
tags: [Windows, Note]
permalink: /articles/2019/08/15/1565860731902.html
---
![](https://img.hacpai.com/bing/20190109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![](https://img.hacpai.com/bing/20181015.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 2019-08-15-Windows 开机自启动特定虚拟机

## 1. VMware 设置

### 1. 查看启动参数

首先右键桌面上的快捷方式打开 Vmware 的安装目录，在 cmd 里输入 `你的安装目录\vmrun.exe` 回车运行、查看 `vmrun.exe` 的使用帮助命令、在最上面可以找到我们所需要的信息：

![2019-08-15-7.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-7.png)

可以看到：如若想启动一个虚拟机、只需要将对应的 `vmx` 文件的绝对路径作为参数传入即可。

```bash
# 你可以在 cmd 窗口运行进行一下测试
"E:\Program Files (x86)\VMware\VMware Workstation\vmrun.exe" start "Path to vmx file"
```

### 2. 使用任务计划

1. 使用 Windows 的搜索功能、键入 `task` 关键字即可看到、`任务计划程序` 这一程序、打开（如下图）。

![2019-08-15-0.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-0.png)

2. 新建计划任务

![2019-08-15-1.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-1.png)

3. 对计划任务进行命名与介绍

![2019-08-15-2.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-2.png)

4. 设置任务触发器为开启启动

![2019-08-15-3.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-3.png)

5. 操作为启动一个程序

![2019-08-15-4.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-4.png)

1. 浏览添加 vmrun.exe

![2019-08-15-5.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-5.png)

7. 点击完成、右键计划任务、运行进行测试

![2019-08-15-6.png](http://tc.zzutcy.top/images/2019/08/15/2019-08-15-6.png)

## 2. VirtualBox 设置

### 1. VirtualBox 设置与 Vmware 类似、只是启动命令不同如下：

```bash
# VirtualBoxVM.exe 的绝对路径、加上 -startvm 选项 + 虚拟机名字即可
"E:\Program Files\Oracle\VirtualBox\VirtualBoxVM.exe" -startvm linux-docker-test
```

### 2. 计划任务设置见 Vmware 计划任务设置
