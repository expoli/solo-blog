title: future-architect/vuls
date: '2019-07-26 12:46:08'
updated: '2019-07-26 12:46:08'
tags: [vuls]
permalink: /articles/2019/07/26/1564656214837.html
---
# 2019-07-26-future-architect/vuls

## docker 部署

### Tutorial - Scan using Docker

官方文档：[https://vuls.io/docs/en/tutorial-docker.html#goval](https://vuls.io/docs/en/tutorial-docker.html#goval)

### install/update go-cve-dictionary

```bash
$ docker pull vuls/go-cve-dictionary
$ docker run  --rm  vuls/go-cve-dictionary -v

go-cve-dictionary v0.1.xxx xxxx
```

### install/update goval-dictionary

```bash
$ docker pull vuls/goval-dictionary
$ docker run  --rm  vuls/goval-dictionary -v

goval-dictionary v0.1.xxx xxxx
```

### install/update gost

```bash
$ docker pull vuls/gost
$ docker run  --rm  vuls/gost  -v

gost  v0.1.xxx xxxx
```
### install/update go-exploitdb

### install/update Vuls

```bash
$ docker pull vuls/vuls
$ docker run  --rm  vuls/vuls -v

vuls v0.1.xxx xxxx
```

## Scan

### Step0. Prepare Log Dir

```bash
$ cd /path/to/working/dir
$ mkdir go-cve-dictionary-log goval-dictionary-log gost-log
```

### Step1. Fetch NVD

```bash
$ for i in `seq 2002 $(date +"%Y")`; do \
    docker run --rm -it \
    -v $PWD:/vuls \
    -v $PWD/go-cve-dictionary-log:/var/log/vuls \
    vuls/go-cve-dictionary fetchnvd -years $i; \
  done
```

### Step2. Fetch OVAL (e.g. redhat)

```bash
$ docker run --rm -it \
    -v $PWD:/vuls \
    -v $PWD/goval-dictionary-log:/var/log/vuls \
    vuls/goval-dictionary fetch-redhat 5 6 7
```

### Step3. Fetch gost(Go Security Tracker) (for RedHat/CentOS and Debian)

```bash
$ docker run --rm -i \
    -v $PWD:/vuls \
    -v $PWD/goval-log:/var/log/gost \
    vuls/gost fetch redhat
```

### Step4. Configuration

```yaml
[servers]

[servers.c74]
host         = "54.249.93.16"
port        = "22"
user        = "vuls-user"
keyPath     = "/root/.ssh/id_rsa" # path to ssh private key in docker
```

### Step5. Configtest

```bash
$ docker run --rm -it\
    -v ~/.ssh:/root/.ssh:ro \
    -v $PWD:/vuls \
    -v $PWD/vuls-log:/var/log/vuls \
    vuls/vuls configtest \
    -config=./config.toml # path to config.toml in docker
```

### Step6. Scan

```bash
$ docker run --rm -it \
    -v ~/.ssh:/root/.ssh:ro \
    -v $PWD:/vuls \
    -v $PWD/vuls-log:/var/log/vuls \
    -v /etc/localtime:/etc/localtime:ro \
    -e "TZ=Asia/Tokyo" \
    vuls/vuls scan \
    -config=./config.toml # path to config.toml in docker

# If Docker Host is Debian or Ubuntu

$ docker run --rm -it \
    -v ~/.ssh:/root/.ssh:ro \
    -v $PWD:/vuls \
    -v $PWD/vuls-log:/var/log/vuls \
    -v /etc/localtime:/etc/localtime:ro \
    -v /etc/timezone:/etc/timezone:ro \
    vuls/vuls scan \
    -config=./config.toml # path to config.toml in docker
```

### Step7. Report

config.toml

```toml
[cveDict]
type = "sqlite3"
SQLite3Path = "/path/to/cve.sqlite3"

[ovalDict]
type = "sqlite3"
SQLite3Path = "/path/to/oval.sqlite3"

[gost]
type = "sqlite3"
SQLite3Path = "/path/to/gost.sqlite3"

[exploit]
type = "sqlite3"
SQLite3Path = "/path/to/go-exploitdb.sqlite3"
```

```bash
$ docker run --rm -it \
    -v ~/.ssh:/root/.ssh:ro \
    -v $PWD:/vuls \
    -v $PWD/vuls-log:/var/log/vuls \
    -v /etc/localtime:/etc/localtime:ro \
    vuls/vuls report \
    -format-short-text \
    -config=./config.toml # path to config.toml in docker
```

### Step8. vulsrepo

```bash
$docker run -dt \
    -v $PWD:/vuls \
    -p 5111:5111 \
    vuls/vulsrepo
```

## HTTP-Server mode

### go-cve
```bash
$ docker run -dt \
    --name go-cve-dictionary \
    -v $PWD:/vuls \
    -v $PWD/go-cve-dictionary-log:/var/log/vuls \
    --expose 1323 \
    -p 1323:1323 \
    vuls/go-cve-dictionary server --bind=0.0.0.0
```
### goval
```bash
$ docker run -dt \
    --name goval-dictionary \
    -v $PWD:/vuls \
    -v $PWD/goval-dictionary-log:/var/log/vuls \
    --expose 1324 \
    -p 1324:1324 \
    vuls/goval-dictionary server --bind=0.0.0.0
```
### gost
```bash
$ docker run -dt \
    --name gost \
    -v $PWD:/vuls \
    -v $PWD/gost-log:/var/log/gost \
    --expose 1325 \
    -p 1325:1325 \
    vuls/gost server --bind=0.0.0.0
```
### Report
```bash
[cveDict]
type = "http"
url = "http://hostname:1323"

[ovalDict]
type = "http"
url = "http://hostname:1324"

[gost]
type = "http"
url = "http://hostname:1325"

[exploit]
type = "http"
url = "http://hostname:1326"
```
```bash
$ docker run --rm -it \
    -v ~/.ssh:/root/.ssh:ro \
    -v $PWD:/vuls \
    -v $PWD/vuls-log:/var/log/vuls \
    vuls/vuls report  \
    -config=./config.toml
```
<!-- 



## 下载文件

```bash
$ sudo yum -y install sqlite git gcc make wget
$ wget wget https://dl.google.com/go/go1.12.7.linux-amd64.tar.gz
$ sudo tar -C /usr/local -xzf go1.12.7.linux-amd64.tar.gz
$ mkdir $HOME/go
```

## 将下面几行导入到 `/etc/profile.d/goenv.sh` 文件中

```bash
export GOROOT=/usr/local/go
export GOPATH=$HOME/go
export PATH=$PATH:$GOROOT/bin:$GOPATH/bin
```

## 刷新一下配置文件

```bash
$ source /etc/profile.d/goenv.sh
```

## 部署 go-cve-dictionary

```bash
$ sudo mkdir /var/log/vuls
$ useradd centos
$ sudo chown centos /var/log/vuls
$ sudo chmod 700 /var/log/vuls
$ mkdir -p $GOPATH/src/github.com/kotakanbe
$ cd $GOPATH/src/github.com/kotakanbe
$ git clone https://github.com/kotakanbe/go-cve-dictionary.git
$ cd go-cve-dictionary
$ make install
``` -->