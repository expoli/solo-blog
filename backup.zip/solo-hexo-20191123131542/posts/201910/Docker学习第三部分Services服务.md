title: Docker 学习第三部分——Services（服务）
date: '2019-10-08 20:42:32'
updated: '2019-10-08 20:42:46'
tags: [Note, Docker]
permalink: /articles/2019/10/08/1570538552570.html
---
![](https://img.hacpai.com/bing/20180227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Get Started, Part 3: Services

## 0 Prerequisites（先决条件）

- 安装Docker 1.13或更高版本。  
  
- 获取Docker Compose。在适用于Mac和Windows的Docker桌面上，它已经预先安装了，因此您可以直接使用。在Linux系统上，您需要手动安装它。在没有Hyper-V功能的Windows 10的系统上，您可以使用Docker Toolbox。  
  
- 阅读第1部分中的 orientation。

- 在第 2 部分中了解如何创建容器。  
  
- 确保通过将 `friendlyhello` 映像推送到注册表来发布您创建的映像。我们在这里使用共享镜像。  
  
- 确保映像用作已部署的容器。运行此命令，在信息中键入用户名、回购和标记：`docker run -p 4000:80 username/repo:tag`，然后访问`http://localhost:4000/`。

## 1. Introduction

在第3部分中，我们扩展应用程序并启用负载平衡。为此，我们必须在分布式应用程序的层次结构中上一层：**服务**。

* Stack
* **Services** (you are here)
* Container (covered in [part 2](https://docs.docker.com/get-started/part2/))

## 2 About services

在分布式应用程序中，应用程序的不同部分称为“服务”。例如，如果您想象一个视频共享站点，则它可能包括用于将应用程序数据存储在数据库中的服务，用于在用户上传内容后在后台进行视频转码的服务，用于前端的服务等。

服务实际上只是“生产中的容器”。服务仅运行一个映像，但它统一了映像的运行方式-它应使用的端口，应运行的容器副本的数量，以便该服务具有所需的容量，以及以此类推。扩展服务会更改运行该软件的容器实例的数量，从而在流程中为该服务分配更多的计算资源。

幸运的是，使用Docker平台定义，运行和扩展服务非常容易-只需编写 `docker-compose.yml` 文件即可。

## 3 Your first `docker-compose.yml` file

docker-compose.yml文件是一个YAML文件，用于定义Docker容器在生产中的行为。

### 3.1 `docker-compose.yml`

找个你所中意的地方，将下面的文件保存为 `docker-compose.yml`, 请确保将第 2 部分中创建的映像推送到注册表，并通过将 `username/repo:tag` 替换为映像详细信息来更新此  `.yml`。

```yaml
version: "3"
services:
  web:
    # replace username/repo:tag with your name and image details
    image: username/repo:tag
    deploy:
      replicas: 5
      resources:
        limits:
          cpus: "0.1"
          memory: 50M
      restart_policy:
        condition: on-failure
    ports:
      - "4000:80"
    networks:
      - webnet
networks:
  webnet:
```

这个`docker-compose.yml`文件告诉Docker执行以下操作：

- 从注册表中提取我们在步骤2中上传的图像。  
  
- 运行该映像的5个实例作为名称为Web的服务，限制每个实例最多使用一个内核时间的10％（也可以是“ 1.5”，表示每个内核有1个半内核），并且50MB的RAM。  
  
- 如果其中一个发生故障，请立即重新启动容器。  
  
- 将主机上的端口4000映射到 web 服务的端口80。  
  
- 指示 `web` 的容器通过称为`webnet`的负载平衡网络共享端口80。 （在内部，容器本身将临时端口发布到 web 的80端口。）  
  
- 使用默认设置定义Webnet网络（这是一个负载平衡的覆盖网络）。

## 4 Run your new load-balanced app

在使用 `docker stack deploy`命令之前，我们首先运行：

```
docker swarm init
```

> 注意：我们将在第4部分中了解该命令的含义。如果不运行 `docker swarm init`，则会收到错误消息“此节点不是swarm管理器”。

现在运行它。您需要给您的应用命名。在这里，它设置为getstartedlab：
获取我们应用程序中一项服务的服务ID：
```
docker service ls
```

查找以您的应用程序名称开头的Web服务的输出。如果您使用的名称与本示例中的名称相同，则名称为getstartedlab_web。还将列出服务ID，以及副本数，映像名称和公开的端口。

或者，您可以运行 `docker stack services`，后跟堆栈的名称。以下示例命令使您可以查看与getstartedlab堆栈关联的所有服务：

```
docker stack services getstartedlab
ID                  NAME                MODE                REPLICAS            IMAGE               PORTS
bqpve1djnk0x        getstartedlab_web   replicated          5/5                 username/repo:tag   *:4000->80/tcp
```

在服务中运行的单个容器称为任务。任务会获得唯一的ID，这些ID会按数字递增，直至您在docker-compose.yml中定义的副本数。列出您的服务任务：

```
docker service ps getstartedlab_web
```

如果仅列出系统上的所有容器，也会显示任务，尽管不会按服务过滤：

```
docker container ls -q
```

您可以连续多次运行 `curl -4 http://localhost:4000`，或者在浏览器中转到该URL，然后单击几次刷新。

![Hello World in browser](https://docs.docker.com/get-started/images/app80-in-browser.png)

无论哪种方式，容器ID都会发生变化，这说明了负载平衡。对于每个请求，将以循环方式选择5个任务之一进行响应。容器ID与您先前命令（docker container ls -q）的输出匹配。

要查看堆栈的所有任务，可以运行docker stack ps，后跟您的应用程序名称，如以下示例所示：

```
docker stack ps getstartedlab
ID                  NAME                  IMAGE               NODE                DESIRED STATE       CURRENT STATE           ERROR               PORTS
uwiaw67sc0eh        getstartedlab_web.1   username/repo:tag   docker-desktop      Running             Running 9 minutes ago                       
sk50xbhmcae7        getstartedlab_web.2   username/repo:tag   docker-desktop      Running             Running 9 minutes ago                       
c4uuw5i6h02j        getstartedlab_web.3   username/repo:tag   docker-desktop      Running             Running 9 minutes ago                       
0dyb70ixu25s        getstartedlab_web.4   username/repo:tag   docker-desktop      Running             Running 9 minutes ago                       
aocrb88ap8b0        getstartedlab_web.5   username/repo:tag   docker-desktop      Running             Running 9 minutes ago
```

> 运行Windows 10？
> Windows 10 PowerShell应该已经可以使用curl了，但是如果没有，您可以使用Linux终端仿真器（如Git BASH），或下载与其非常相似的wget for Windows。

> 响应时间慢？
> 根据您环境的网络配置，容器最多可能需要30秒才能响应HTTP请求。这并不是Docker或集群性能的指标，而是我们未在本教程后面解决的Redis依赖关系的未满足。目前，访客计数器由于相同的原因而无法运行；我们尚未添加服务来保留数据。

## 5 Scale the app

您可以通过更改docker-compose.yml中的 `replicas` 值，保存更改并重新运行docker stack deploy命令来扩展应用程序：

```
docker stack deploy -c docker-compose.yml getstartedlab
```

Docker执行就地更新，无需先拆除堆栈或杀死任何容器。现在，重新运行 `docker container ls -q` 来查看已重新配置的已部署实例。如果按比例扩大副本，则会启动更多任务，从而启动更多容器。

### 5.1 Take down the app and the swarm

- 使用docker stack rm关闭应用程序：
```
docker stack rm getstartedlab
```
- 离开集群
```
docker swarm leave --force
```

使用 Docker 站起来并扩展应用非常简单。您在学习如何在生产中运行容器方面迈出了一大步。接下来，您将学习如何在 Docker 计算机群集上以真正的集群形式运行此应用程序。

> 注意：像这样撰写的文件不仅可以使用 Docker 定义应用程序，而且可以使用 Docker Cloud 上载到云提供商，也可以上载到使用 Docker 企业版选择的任何硬件或云提供商。

[On to “Part 4” >>](https://docs.docker.com/get-started/part4/)

## 6 Recap and cheat sheet (optional)

这是此页面所涵盖内容的终端视频记录：https://asciinema.org/a/b5gai4rnflh7r0kie01fx6lip

回顾一下，虽然键入docker run非常简单，但是生产中容器的真正实现是将其作为服务运行。服务在Compose文件中整理了容器的行为，该文件可用于缩放，限制和重新部署我们的应用。可以使用启动服务的相同命令，在服务运行时就地对服务进行更改：docker stack deploy。

现阶段要探索的一些命令：

```bash
docker stack ls                                            # List stacks or apps
docker stack deploy -c <composefile> <appname>  # Run the specified Compose file
docker service ls                 # List running services associated with an app
docker service ps <service>                  # List tasks associated with an app
docker inspect <task or container>                   # Inspect task or container
docker container ls -q                                      # List container IDs
docker stack rm <appname>                             # Tear down an application
docker swarm leave --force      # Take down a single node swarm from the manager
```
