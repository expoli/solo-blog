title: 在 centos 上安装 zabbix-agent
date: '2019-07-30 12:47:08'
updated: '2019-08-19 19:50:15'
tags: [CentOS, zabbix]
permalink: /articles/2019/07/30/1564656213661.html
---
# 在 centos 上安装 zabbix-agent

## 0. 背景

最近实验室老师给我们新配置了一台服务器、品牌为浪潮的储存服务器，6块3T HGST 硬盘，自带硬件 raid 卡，使用%块硬盘配置了 raid 5，余下一块硬盘作为热备盘。最终硬盘容量为 12 TB。

浪潮储存服务器、出厂系统为他们自己的大容量储存管理软件，里面包括了一些文件共享程序，比如：FTP、NFS也提供了LADP认证服务器功能，但是在经过试用过后、发现确实不怎么好用。。。。

于是就安装了 `centos 7` ，在配置了一些基础的服务之后、现在需要做的就是给他加上监控、要不然的话、不知道机器的运行状态、让人心里很没有底啊

## 1. 添加 zabbix 源

```bash
rpm -ivh https://repo.zabbix.com/zabbix/4.2/rhel/7/x86_64/zabbix-release-4.2-1.el7.noarch.rpm
```

![2019-03-30-install-zabbix-agent-on-centos7-4.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-install-zabbix-agent-on-centos7-4.png)

```bash
# 开启源
yum-config-manager --enable rhel-7-server-optional-rpms

# 开始安装
yum install zabbix-agent
```

## 2. 修改配置文件

```bash
vim /etc/zabbix/zabbix_agentd.conf

# zabbix server IP 、被动模式、即允许向我询问状态的 zabbix-server IP地址
Server=192.168.0.*
# 主动模式的 zabbix server IP地址与端口
ServerActive=192.168.0.*:10051
# zabbix-server 上配置的主机名称
Hostname=openwrt-route-********
```

## 3. 启动并查看启动状态

### 1. 启动服务并查看端口监听状态

```bash
# 设置开机启动
systemctl enable zabbix-agent
# 启动
systemctl start zabbix-agent
# 查看状态
systemctl status zabbix-agent
# 查看端口监听状态
netstat -ntlp
```

![2019-03-30-install-zabbix-agent-on-centos7-1.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-install-zabbix-agent-on-centos7-1.png)

### 2. 查看防火墙状态

```bash
# 查看已经开启的端口或服务
firewall-cmd --list-all
# 查看所支持的关于 zabbix 的服务
firewall-cmd --get-services | grep zabbix
```
![2019-03-30-install-zabbix-agent-on-centos7-2.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-install-zabbix-agent-on-centos7-2.png)

从上图可以发现 zabbix-agent 服务的端口并没有放行，所以现在 zabbix-server 不能连接到 zabbix-agent。

### 3. 将 zabbix-agent 服务添加到防火墙例外中

![2019-03-30-install-zabbix-agent-on-centos7-3.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-install-zabbix-agent-on-centos7-3.png)

现在就已经将 zabbix-agent 安装完成了。