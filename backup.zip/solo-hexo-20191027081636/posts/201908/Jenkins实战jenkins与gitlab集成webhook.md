title: Jenkins实战-jenkins与gitlab集成（webhook)
date: '2019-08-18 16:55:15'
updated: '2019-08-19 20:49:45'
tags: [运维, Jenkins, Git]
permalink: /articles/2019/08/18/1566118515630.html
---
![](https://img.hacpai.com/bing/20190604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Jenkins实战-jenkins与gitlab集成（webhook)

## 1. 安装对应的插件

### 1.1 打开 Manage Jenkins

### 1.2 点击 Plugin Manager

### 1.3 点击 Available

### 1.4 搜索安装下列插件（只安装不重启）

### 1.5 插件列表

- GitLab Plugin
- Gitlab Hook Plugin
- Build Token Trigger Plugin
- Git plugin
- GitHub Branch Source Plugin
- Pipeline
- Build Authorization Token Root
- Build Pipeline Plugin

### 1.6 勾选插件安装完成重启 Jenkins

## 2. 配置 Jenkins 项目信息

### 2.1 新建一个 Item

![9-jenkins-jenkinsgitlabwebhook3.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook3.png)

### 2.2 在这里填入你的项目的 ssh 链接

![9-jenkins-jenkinsgitlabwebhook4.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook4.png)

### 2.3 在源码管理部分中相应的部分填入对应的信息并保存

![9-jenkins-jenkinsgitlabwebhook5.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook5.png)

### 2.4 添加身份认证信息

1. 上图方框中的红色部分是因为没有对应的访问权限、点击 `Add` 按钮、选择 `Jenkins` 加入身份认证密钥。

![9-jenkins-jenkinsgitlabwebhook6.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook6.png)

2. 将下面的四项信息填入保存即可

![9-jenkins-jenkinsgitlabwebhook7.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook7.png)

3. 选择你刚才添加的身份信息

![9-jenkins-jenkinsgitlabwebhook8.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook8.png)

4. 注意 gitlab 版本信息只支持 2 位版本号

### 2.5 配置构建触发器

1. 使用 openssl 生成随机的字符串

```bash
openssl rand -hex 10
267745011b184c02fa72
```

勾选构建触发器、选择远程触发器、填入 token 、同时记录下 `GitLab webhook URL`

![9-jenkins-jenkinsgitlabwebhook0.png](http://tc.expoli.tech/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook0.png)

## 3. 配置 gitlab 项目的 webhook

### 3.1 构建 gitlab webhook URL

1. `Build Token Root Plugin` 官方 wiki、提供了 `gitlab webhook URL` 的构建方式，百度搜索 `Build Token Root Plugin` 计科获得 wiki 链接、查看示例的URL链接

[https://wiki.jenkins.io/display/JENKINS/Build+Token+Root+Plugin](https://wiki.jenkins.io/display/JENKINS/Build+Token+Root+Plugin)

2. 示例代码

```bash
# Examples
# Trigger the RevolutionTest job with the token TacoTuesday

buildByToken/build?job=RevolutionTest&token=TacoTuesday

# Trigger the RevolutionTest job with the token TacoTuesday and parameter Type supplied with the value Mexican

buildByToken/buildWithParameters?job=RevolutionTest&token=TacoTuesday&Type=Mexican
```

3. 根据官方示例构建 webhook 链接

```bash
# 主机地址 + buildByToken + build?job= + 项目名称 + &token= + token
http://192.168.0.239:8080/buildByToken/build?job=auto-deploy&token=267745011b184c02fa72
```

### 3.2 配置 gitlab 项目的 webhook

![9-jenkins-jenkinsgitlabwebhook1.png](http://tc.expoli.tech/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook1.png)

### 3.3 如果出现 `Urlis blocked: Requests to the local network are not allowed` 报错

请开启下面的功能

![9-jenkins-jenkinsgitlabwebhook2.png](http://tc.expoli.tech/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook2.png)

### 3.4 点击 Test 选择 push 事件进行测试

![9-jenkins-jenkinsgitlabwebhook10.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook10.png)

### 3.5 返回 Jenkins 查看构建状态以及构建日志输出

可以在 Jenkins 页面上看到自动构建任务已经开始、点击 `#1` 可以看到详细信息

![9-jenkins-jenkinsgitlabwebhook11.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook11.png)

![9-jenkins-jenkinsgitlabwebhook12.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook12.png)

![9-jenkins-jenkinsgitlabwebhook13.png](http://tc.expoli.tech/images/2019/08/19/9-jenkins-jenkinsgitlabwebhook13.png)

## 4. 进行 git push 测试

### 4.1 修改 git 项目内容

### 4.2 git add

### 4.3 git commit

### 4.4 git push

### 4.5 进入 Jenkins 页面查看执行情况
