title: 持续代码质量管理-Sonar部署
date: '2019-08-18 14:40:13'
updated: '2019-08-19 20:49:27'
tags: [运维, Sonar]
permalink: /articles/2019/08/18/1566110413790.html
---
![](https://img.hacpai.com/bing/20180725.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 持续代码质量管理-Sonar部署

Sonar 是一个用于代码质量管理的开放平台。通过插件机制，Sonar 可以集成不同的测试工具，代码分析工具，以及持续集成工具。与持续集成工具（例如 Hudson/Jenkins 等）不同，Sonar 并不是简单地把不同的代码检查工具结果（例如 FindBugs，PMD 等）直接显示在 Web 页面上，而是通过不同的插件对这些结果进行再加工处理，通过量化的方式度量代码质量的变化，从而可以方便地对不同规模和种类的工程进行代码质量管理。

在对其他工具的支持方面，Sonar 不仅提供了对 IDE 的支持，可以在 Eclipse 和 IntelliJ IDEA 这些工具里联机查看结果；同时 Sonar 还对大量的持续集成工具提供了接口支持，可以很方便地在持续集成中使用 Sonar。 此外，Sonar 的插件还可以对 Java 以外的其他编程语言提供支持，对国际化以及报告文档化也有良好的支持。 


## 1. Sonar部署

需要 java 11+ 才能运行

### 1.1 下载安装包

Sonar的相关下载和文档可以在下面的链接中找到：http://www.sonarqube.org/downloads/。

需要注意最新版的Sonar需要至少JDK 1.8及以上版本。

```bash
yum install -y java-11-openjdk
cd /usr/local/src
wget https://binaries.sonarsource.com/Distribution/sonarqube/sonarqube-7.9.1.zip
unzip sonarqube-7.9.1.zip
mv sonarqube-7.9.1 /usr/local/
ln -s /usr/local/sonarqube-7.9.1/ /usr/local/sonarqube

```

### 1.2 准备Sonar数据库

```bash
mysql> CREATE DATABASE sonar CHARACTER SET utf8 COLLATE utf8_general_ci;
mysql> GRANT ALL ON sonar.* TO 'sonar'@'localhost' IDENTIFIED BY 'sonar@pw';
mysql> GRANT ALL ON sonar.* TO 'sonar'@'%' IDENTIFIED BY 'sonar@pw';
mysql> FLUSH PRIVILEGES;
```

```yaml
version: "2"
services:
  mysql:
    container_name: mysql
    image: mariadb
    restart: always
    ports:
      - "3306:3306"
    volumes:
      - ./mysql/data:/var/lib/mysql
    environment:
      MYSQL_ROOT_PASSWORD: "adminadmin"
      MYSQL_USER: "sonar"
      MYSQL_DATABASE: "sonar"
      MYSQL_PASSWORD: "sonar"
    command: --max_allowed_packet=32505856 --character-set-server=utf8mb4 --collation-server=utf8mb4_general_ci
```

### 1.3 配置Sonar

```bash
# cd /usr/local/sonarqube/conf/
# ls
sonar.properties  wrapper.conf

# 编写配置文件，修改数据库配置
# vim sonar.properties
sonar.jdbc.username=sonar
sonar.jdbc.password=sonae@pw
sonar.jdbc.url=jdbc:mysql://localhost:3306/sonar?useUnicode=true&characterEncoding=utf8&rewriteBatchedStatements=true&useConfigs=maxPerformance
```

### 1.4 配置Java访问数据库驱动(可选)

默认情况Sonar有自带的嵌入的数据库，那么你如果使用类是Oracle数据库，必须手动复制驱动类到 `${SONAR_HOME}/extensions/jdbc-driver/oracle/` 目录下，其它支持的数据库默认提供了驱动。

其它数据库的配置可以参考官方文档： http://docs.sonarqube.org/display/HOME/SonarQube+Platform 

### 1.5 启动Sonar

你可以在Sonar的配置文件来配置Sonar Web监听的IP地址和端口，默认是9000端口。

```bash
[root@linx-node2 conf]# vim sonar.properties
sonar.web.host=0.0.0.0
sonar.web.port=9000
[root@linx-node2 ~]# /usr/local/sonarqube/bin/linux-x86-64/sonar.sh start
```

### 1.6 访问Sonar

http://IP:9000

## 2. docker 启动

```yaml
version: "2"

services:
  sonarqube:
    image: sonarqube
    ports:
      - "9000:9000"
    networks:
      - sonarnet
    environment:
      - sonar.jdbc.url=jdbc:postgresql://db:5432/sonar
#    volumes:
#      - sonarqube_conf:/opt/sonarqube/conf
#      - sonarqube_data:/opt/sonarqube/data
#      - sonarqube_extensions:/opt/sonarqube/extensions

  db:
    image: postgres
    networks:
      - sonarnet
    environment:
      - POSTGRES_USER=sonar
      - POSTGRES_PASSWORD=sonar
    volumes:
      - ./postgresql:/var/lib/postgresql
 # This needs explicit mapping due to https://github.com/docker-library/postgres/blob/4e48e3228a30763913ece952c611e5e9b95c8759/Dockerfile.template#L52
#      - postgresql_data:/var/lib/postgresql/data

networks:
  sonarnet:
    driver: bridge

#volumes:
#  sonarqube_conf:
#  sonarqube_data:
#  sonarqube_extensions:
#  postgresql:
#    - ${PWD}/postgres
#  postgresql_data:

```

## 2. Sonar 配置

### 2.1 修改默认密码


### 2.2 安装中文语言插件

### 2.3 重启 Sonar

### 2.4 安装所需要的语言插件

你需要分析什么语言就安装什么插件

## 3. 安装 SonarQube Scanner

### 3.1 下载解压安装包

```bash
https://docs.sonarqube.org/latest/analysis/scan/sonarscanner/

https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-4.0.0.1744-linux.zip

cd /usr/local/src
wget https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/sonar-scanner-cli-4.0.0.1744-linux.zip
unzip sonar-scanner-cli-4.0.0.1744-linux.zip
mv sonar-scanner-4.0.0.1744-linux/ /usr/local/
ln -s /usr/local/sonar-scanner-4.0.0.1744-linux/ /usr/local/sonar-scanner

```

### 3.2 修改配置文件

```bash
vim /usr/local/sonar-scanner/conf/sonar-scanner.properties

# 修改SonarQube server 地址
#----- Default SonarQube server
sonar.host.url=http://localhost:9000
#----- Default source code encoding
sonar.sourceEncoding=UTF-8
```

### 3.2 将 /usr/local/sonar-scanner/bin 添加到PATH环境变量内

```bash
vim ~/.bashrc
export PATH=$PATH:/usr/local/sonar-scanner/bin
source ~/.bashrc
```

### 3.3 sonar-scanner -h 测试

```bash
sonar-scanner -h

INFO: 
INFO: usage: sonar-scanner [options]
INFO: 
INFO: Options:
INFO:  -D,--define <arg>     Define property
INFO:  -h,--help             Display help information
INFO:  -v,--version          Display version information
INFO:  -X,--debug            Produce execution debug output
```

### 3.4 下载官方的代码例子、进行测试

1. 下载代码例子

```bash
git clone https://github.com/SonarSource/sonar-scanning-examples.git
cd sonar-scanning-examples/sonarqube-scanner/
```

2. 扫描配置文件

```bash
# 需要设置配置文件、才能进行扫描
# cat sonar-scanning-examples/sonarqube-scanner/sonar-project.properties

sonar.projectKey=org.sonarqube:sonarqube-scanner
sonar.projectName=Example of SonarQube Scanner Usage
sonar.projectVersion=1.0

sonar.sources=src,copybooks

sonar.sourceEncoding=UTF-8

## Cobol Specific Properties

# comma-separated paths to directories with copybooks
sonar.cobol.copy.directories=copybooks
# comma-separated list of suffixes
sonar.cobol.file.suffixes=cbl,cpy
sonar.cobol.copy.suffixes=cpy



## Flex Specific Properties

# retrieve code coverage data from the Cobertura report
sonar.flex.cobertura.reportPath=coverage-report/coverage-cobertua-flex.xml



# PL/I Specific Properties
sonar.pli.marginLeft=2
sonar.pli.marginRight=0
######################################################
```

3. 开始测试

```bash
sonar-scanning

#### 输出结果

INFO: Analysis total time: 1:07.280 s
INFO: ------------------------------------------------------------------------
INFO: EXECUTION SUCCESS
INFO: ------------------------------------------------------------------------
INFO: Total time: 1:24.407s
INFO: Final Memory: 15M/54M
INFO: ------------------------------------------------------------------------

```

### 3.5 在Senar 后台仪表盘查看所生成的报告

![Sonar0.png](http://tc.expoli.tech/images/2019/08/18/Sonar0.png)

![Sonar1.png](http://tc.expoli.tech/images/2019/08/18/Sonar1.png)
