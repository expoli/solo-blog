title: Docker 学习第一部分——Orientation and setup
date: '2019-09-22 15:52:19'
updated: '2019-09-22 15:52:19'
tags: [Docker]
permalink: /articles/2019/09/22/1569138739065.html
---
![](https://img.hacpai.com/bing/20190531.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Part 1: Orientation and setup

欢迎！我们很高兴您想学习如何使用Docker。

在这个由六部分组成的教程中，您将学习：
1. 在此页面上做好准备并确定学习方向
2. 构建并运行您的第一个应用将您的应用
3. 将应用转换为缩放服务
4. 将服务跨多台计算机
5. 添加可保留数据的访客计数器
6. 将您的集群部署到生产

## 1.1 先决条件

虽然我们将在此过程中定义概念，但最好在开始之前了解 [Docker 是什么](https://www.docker.com/what-docker)以及[为什么使用 Docker](https://www.docker.com/use-cases)。

在继续之前，我们还需要假定您熟悉一些概念：
- IP地址和端口
- 虚拟机
- 编辑配置文件
- 基本了解代码依赖关系和构建的思想
- 机器资源使用条件，例如CPU百分比，以字节为单位的RAM使用率等。

最后，尽管我们会在需要这些东西时再次提醒您，但是您可以通过注册Docker ID并运行以下命令在本地计算机上使用它，从而节省一些时间：

```
docker login
```

## 1.2 容器的简要说明

映像（**image**）是一个轻量级的，独立的，可执行的程序包，其中包含运行某个软件所需的一切，包括代码，运行时，库，环境变量和配置文件。

容器（**container**）是映像的运行时实例，即映像在实际执行时在内存中的位置。默认情况下，它与主机环境完全隔离运行，仅访问主机文件和端口（如果需要这样做配置）。

容器在主机的内核上本机运行应用。与仅通过虚拟机管理程序虚拟访问主机资源的虚拟机相比，它们具有更好的性能特征。容器可以获取本机访问，每个访问都运行在离散进程中，占用的内存不会比任何其他可执行文件多。

## 1.3 容器 vs 虚拟机

考虑下图比较虚拟机和容器：

### 1.3.1 虚拟机图

虚拟机运行来宾操作系统 — 请注意每个框中的操作系统层。这是资源密集型的，生成的磁盘映像和应用程序状态是操作系统设置、系统安装的依赖项、操作系统安全修补程序和其他容易丢失、难以复制的应用程序状态。

### 1.3.2 容器图

容器可以共享一个内核，并且唯一需要包含在容器映像中的信息是可执行文件及其与程序包的依赖关系，而这些信息永远不需要安装在主机系统上。这些进程像本机进程一样运行，您可以通过运行docker ps等命令来单独管理它们-就像在Linux上运行ps来查看活动进程一样。最后，由于它们包含所有依赖关系，因此没有配置纠缠；容器化的应用程序“可在任何地方运行”。

## 2 Setup

在开始之前，请确保您的系统已安装了最新版本的Docker。

[Install Docker](https://docs.docker.com/v17.09/engine/installation/)

> **Note**: version 1.13 or higher is required

您应该能够运行docker run hello-world并看到如下响应：

> **Note**:您可能需要将用户添加到`docker` 组中，才能在不使用sudo的情况下调用此命令。[阅读更多](https://docs.docker.com/v17.09/engine/installation/linux/linux-postinstall/

> **Note**:如果您的设置中存在网络问题，则 `docker run hello-world` 可能无法成功执行。如果您位于代理服务器后面，并且怀疑它阻止了连接，请检查本教程的下一部分。

```
$ docker run hello-world

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
...(snipped)...
```

现在也是确认您使用的是不是1.13版或更高版本Docker的好时机。运行 `docker --version` 进行检查。

```
$ docker --version
Docker version 17.05.0-ce-rc1, build 2878a85
```


如果您看到上述信息，则可以开始您的旅程了。

## 3. 结论

规模单位是一个单独的、可移植的可执行文件，具有巨大的意义。这意味着 CI\/CD 可以将更新推送到分布式应用程序的任何部分，系统依赖项不是问题，并且资源密度会增加。缩放行为的编排是启动新可执行文件的问题，而不是新的 VM 主机。

我们将学习所有这些事情，但是首先我们需要先学会走路。

[第二部分](https://docs.docker.com/v17.09/get-started/part2/)
