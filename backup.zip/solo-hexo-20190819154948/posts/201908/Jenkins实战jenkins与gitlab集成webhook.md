title: Jenkins实战-jenkins与gitlab集成（webhook)
date: '2019-08-18 16:55:15'
updated: '2019-08-18 16:55:15'
tags: [运维, Jenkins, Git]
permalink: /articles/2019/08/18/1566118515630.html
---
![](https://img.hacpai.com/bing/20190223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Jenkins实战-jenkins与gitlab集成（webhook)

## 1. 安装对应的插件

### 1.1 安装 gitlab hook plugin

## 2. 配置 Jenkins

### 2.1 安装 Build Authorization Token Root 插件、进行身份令牌认证

1. 可以使用 openssl 生成随机的字符串

```bash
openssl rand -hex 10
267745011b184c02fa72
```
### 2.2 配置 Jenkins 项目

勾选构建触发器、选择远程触发器、填入 token 、同时记录下 `GitLab webhook URL`

![9-jenkins-jenkinsgitlabwebhook0.png](http://tc.zzutcy.top/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook0.png)

## 3. 配置 gitlab 的项目配置

### 3.1 构建 gitlab webhook URL

1. 打开 `Build Token Root Plugin` 官方 wiki、查看示例的URL链接

https://wiki.jenkins.io/display/JENKINS/Build+Token+Root+Plugin

```bash
# Examples
# Trigger the RevolutionTest job with the token TacoTuesday

buildByToken/build?job=RevolutionTest&token=TacoTuesday

# Trigger the RevolutionTest job with the token TacoTuesday and parameter Type supplied with the value Mexican

buildByToken/buildWithParameters?job=RevolutionTest&token=TacoTuesday&Type=Mexican
```

2. 根据官方示例构建 webhook 链接

```bash
http://192.168.0.239:8080/buildByToken/build?job=auto-deploy&token=267745011b184c02fa72
```

### 3.2 配置gitlab项目的webhook

![9-jenkins-jenkinsgitlabwebhook1.png](http://tc.zzutcy.top/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook1.png)

### 3.3 如果出现 `Urlis blocked: Requests to the local network are not allowed` 报错

请开启下面的功能

![9-jenkins-jenkinsgitlabwebhook2.png](http://tc.zzutcy.top/images/2019/08/18/9-jenkins-jenkinsgitlabwebhook2.png)

### 3.4 点击 Test 选择 push 事件进行测试

可以在 Jenkins 页面上看到自动构建任务已经开始

## 4. 进行 git push 测试

### 4.1 修改 git 项目内容

### 4.2 git add

### 4.3 git commit

### 4.4 git push

### 4.5 进入 Jenkins 页面查看执行情况

