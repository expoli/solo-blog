title: Openwrt X86（32位）编译安装笔记
date: '2019-03-14 20:46:08'
updated: '2019-03-14 20:46:08'
tags: [Openwrt, 计算机网络, 运维]
permalink: /articles/2019/03/14/1564656236948.html
---
# 一、编译

- **时间**： `2019.03.10`

- **参考**： [https://www.jianshu.com/p/cb82b1521a8d](https://www.jianshu.com/p/cb82b1521a8d)

- **系统环境**：`Ubuntu 16.04`

- openwrt源：[https://github.com/openwrt/openwrt.git](https://github.com/openwrt/openwrt.git)

# 二、配置环境

```bash
# 安装依赖
sudo apt-get install build-essential git-core libncurses5-dev zlib1g-dev gawk flex quilt libssl-dev xsltproc libxml-parser-perl mercurial bzr ecj cvs unzip asciidoc binutils bzip2 gettext subversion patch

#　如果是64位系统、还需安装32位兼容包
sudo apt-get install libc6:i386 libgcc1:i386 libstdc++5:i386 libstdc++6:i386
```

# 三、编译步骤

## 1、下载源码包

```bash
# 下载源码包
cd （自己喜欢的目录
git clone https://github.com/openwrt/openwrt.git
# 或者 wget https://github.com/openwrt/openwrt/archive/master.zip && unzip master.zip 
cd openwrt
```

## 2、修改 feeds 源为 github 源

```bash
# 查看文件feeds.conf.default   
# 因为lede和openwrt合并之后　feeds 的 git.openwrt.org 源已经不好用了所以将原来的源更改为 github 源

##################################### 原文件
src-git packages https://git.openwrt.org/feed/packages.git
src-git luci https://git.openwrt.org/project/luci.git
src-git routing https://git.openwrt.org/feed/routing.git
src-git telephony https://git.openwrt.org/feed/telephony.git
#src-git video https://github.com/openwrt/video.git
#src-git targets https://github.com/openwrt/targets.git
#src-git management https://github.com/openwrt-management/packages.git
#src-git oldpackages http://git.openwrt.org/packages.git
#src-link custom /usr/src/openwrt/custom-feed

##################################### 更改为
src-git packages https://github.com/openwrt/packages.git
src-git luci https://github.com/openwrt/luci.git
src-git routing https://github.com/openwrt-routing/packages.git
src-git telephony https://github.com/openwrt/telephony.git
src-git management https://github.com/openwrt-management/packages.git
```

## 3、更新 Feeds

```bash
# Updating Feeds
./scripts/feeds update -a
./scripts/feeds install -a 

# 等待完成。。。。。
```

## 4、编译配置

```bash
# 检查编译依赖
make defconfig

# 编译选项配置界面 （重点！！！）
make menuconfig # 仔细看界面上面的帮助

# 设置目标编译平台
(Target System)->x86    # x86 应该是最后一个
(Subtarget)->Generic
(Target Profile)->Generic
(Target Images) # 这里面是配置镜像参数的、包括生成的镜像类型、Kernel与Root分区的大小
(Kernel modules) -> (Netfilter Extensions) -> kmod-ipt-nat6 # nat IPV6 内核模块
(kernel modules->USB support) # 如果usb键盘则需要选择 kmod-usb-hid
# 我用一个X86的软网关 刷官方固件后开机不能识别网卡，需要添加：
(kernel modules) -> (Nework Devices) -> (kmod-e1000e) # 才能识别出eth0\1\2\3\..)

```

##　5、开始编译

```bash
# 下载编译所需文件
make download V=s # emmmm 因国内网络环境，所以这个过程会很漫长。。。

# 开始编译

# (第一次编译）
make V=99  # 完成编译 结束。

# (非第一次)  
ulimit -s 10240 # emmmmm 不清楚什么意思

make V=99 -j 线程数  
# (eg:make V=99 -j2)
# 然后静静等待编译结束。（时间视情况而定、Intel(R) Core(TM) i5-7500 CPU @ 3.40GHz 4 线程，大约使用了3h

#　生成的文件在bin/系列名/ 下面 
```

## 6、进行安装

### 1.制作一个 Linux 启动盘

因为编译生成的文件是 `**combined-ext4.img.gz` 的文件，所以没有办法直接把镜像烧录到软路由的硬盘里面，需要使用一个 Linux Live CD 进行中转写入。

制作 Linux （在这里推荐使用 Ubuntu 桌面版）启动盘，可以使用 `Rufus` 将镜像文件写入U盘。

### 2.准备好你编译好的镜像文件

将你编译好的镜像文件或者你下载的镜像放入一个U盘或者放入你做的 Linux 启动盘分区里面。

### 3.设置你的软路由从U盘启动

现在的主板一般都支持UEFI启动，在 BIOS 和 UEFI 中选择你自己喜欢的启动方式进行启动。

### 4.解压镜像文件

在 Live CD 里面找到你的镜像文件（****ext4.img.gz)，右键压缩文件,得到`***combined-ext4.img` 镜像文件。

### 5.挂载镜像准备将镜像写入到硬盘

```bash
# 建立挂载文件夹
sudo mkdir -p /mnt/openwrt

#　找到硬盘的描述代号
sudo fdisk -l 

# dd 写入镜像
sudo dd if=***combined-ext4.img of=/dev/sd($) bs=1M count=100

# .... 等待完成 ....

# 因为默认硬盘大小是编译的时候确定的，有可能你感觉圣盘空间剩余太大，使用空间太小，你可以使用 gparted 修改分区大小

```