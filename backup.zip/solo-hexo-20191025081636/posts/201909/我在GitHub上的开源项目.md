title: 我在 GitHub 上的开源项目
date: '2019-09-08 13:31:34'
updated: '2019-09-08 13:33:22'
tags: [开源, Github]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [My_blog_backup](https://github.com/expoli/My_blog_backup) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/expoli/My_blog_backup/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/expoli/My_blog_backup/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/My_blog_backup/network/members "分叉数")</span>





---

### 2. [solo-blog](https://github.com/expoli/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/expoli/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://expoli.tech`](https://expoli.tech "项目主页")</span>

糖醋鱼的小破站 - 🐟生成长记



---

### 3. [zzu-embedded](https://github.com/expoli/zzu-embedded) <kbd title="主要编程语言">C</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/expoli/zzu-embedded/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/zzu-embedded/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/expoli/zzu-embedded/network/members "分叉数")</span>

郑州大学电子信息工程嵌入式实验



---

### 4. [WiFi-control-led-arduino-D1-mini](https://github.com/expoli/WiFi-control-led-arduino-D1-mini) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/expoli/WiFi-control-led-arduino-D1-mini/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/WiFi-control-led-arduino-D1-mini/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/WiFi-control-led-arduino-D1-mini/network/members "分叉数")</span>

通过WiFi的udp通信控制继电器继电器工作,实现对led的控制



---

### 5. [Electronic-system-practice](https://github.com/expoli/Electronic-system-practice) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/expoli/Electronic-system-practice/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/Electronic-system-practice/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Electronic-system-practice/network/members "分叉数")</span>

Electronic system practice 郑州大学电子系统设计实践



---

### 6. [python_web_practies](https://github.com/expoli/python_web_practies) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/expoli/python_web_practies/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/python_web_practies/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/python_web_practies/network/members "分叉数")</span>





---

### 7. [bt_panel_docker_vlome](https://github.com/expoli/bt_panel_docker_vlome) <kbd title="主要编程语言">C</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/expoli/bt_panel_docker_vlome/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/bt_panel_docker_vlome/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/bt_panel_docker_vlome/network/members "分叉数")</span>

bt_panel_docker_vlome 宝塔Linux面板v6.8 /www 挂载目录



---

### 8. [hexo-theme-yilia-all-in-one](https://github.com/expoli/hexo-theme-yilia-all-in-one) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/expoli/hexo-theme-yilia-all-in-one/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/expoli/hexo-theme-yilia-all-in-one/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/hexo-theme-yilia-all-in-one/network/members "分叉数")</span>



