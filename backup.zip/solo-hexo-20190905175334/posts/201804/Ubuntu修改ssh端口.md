title: Ubuntu修改ssh端口
date: '2018-04-27 09:29:59'
updated: '2018-04-27 09:29:59'
tags: [Ubuntu]
permalink: /articles/2018/04/27/1564656226041.html
---
![SSH](https://ws1.sinaimg.cn/large/006tNbRwly1fwblwgg44ej30p00fk0t7.jpg)

### 首先安装 **openssh-server**

<!-- more -->

```bash
$ sudo apt-get install openssh-server
```

### 修改配置文件
``` bash
$ sudo vim /etc/ssh/sshd_config
```

### 在Port 22下添加你的端口

上一步打开配置文件后，找到 `# port 22` 这一行

把 `# port 22` 前面的 # 去掉，并在下一行添加 你想要使用的端口 `eg: Port ****`

### 保存你的修改

按下 `ESC` 键进入 `vim` 的普通模式 输入 `:wq` 进行存盘推出

### 修改保存后 重启服务

``` bash
$ sudo /etc/init.d/ssh restart     
```
or
``` bash
$ sudo service ssh restart 
```

### **然后在防火墙开启相应端口**，进行测试 

一定不要忘记在防火墙上开启相应端口！！！

一定不要忘记在防火墙上开启相应端口！！！

一定不要忘记在防火墙上开启相应端口！！！

（注意现在ssh同时工作在22和你设定的端口下，测试完毕后你可以选择把22端口注释掉。）

### OK！ 大功告成！