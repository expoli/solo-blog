title: nginx 主配置文件 nginx.conf 学习
date: '2019-07-27 20:47:08'
updated: '2019-07-27 20:47:08'
tags: [Nginx]
permalink: /articles/2019/07/27/1564656221533.html
---
# nginx 主配置文件 `nginx.conf` 学习

虽然使用 nginx 作为 web 服务器体精很久了、但是对 nginx 配置文件里面的各个参数配置、的功能依旧不甚了解、所以在这里做个笔记、避免自己遗忘。

原文链接：[https://www.oschina.net/translate/nginx-setup?cmp](https://www.oschina.net/translate/nginx-setup?cmp)

## 主配置文件

### 0. 路径 `/etc/nginx/nginx.conf`

### 1. 高层的配置

`nginx.conf` 文件中，Nginx中有少数的几个高级配置在模块部分之上。

```bash
user www-data;
pid /var/run/nginx.pid;

worker_processes auto;

worker_rlimit_nofile 100000;
```

- user pid

user和pid应该按默认设置 - 我们不会更改这些内容，因为更改与否没有什么不同。

- worker_processes

`worker_processes` 定义了 `nginx` 对外提供web服务时的 `worder进程数`。最优值取决于许多因素，包括（但不限于）CPU核的数量、存储数据的硬盘数量及负载模式。不能确定的时候，将其设置为可用的CPU内核数将是一个好的开始（设置为“auto”将尝试自动检测它）。

- worker_rlimit_nofile

`worker_rlimit_nofile` 更改`worker` 进程的最大打开文件数限制。如果没设置的话，这个值为操作系统的限制。

设置后你的操作系统和Nginx可以处理比 `“ulimit -a”` 更多的文件，所以把这个值设高，这样nginx就不会有`“too many open files”` 问题了。

### 2. Events模块

`events` 模块中包含 `nginx` 中所有 `处理连接` 的设置。

```nginx
events {
    worker_connections 2048;
    multi_accept on;
    use epoll;
}
```

- worker_connections

`worker_connections` 设置可由一个`worker` 进程同时打开的 `最大连接数`。

如果设置了上面提到的`worker_rlimit_nofile`，我们可以将这个值设得很高。

记住，最大客户数也由 `系统的可用socket连接数限制（~ 64K）`，所以设置不切实际的高没什么好处。

- multi_accept

`multi_accept` 告诉 `nginx` 收到一个新连接通知后接受尽可能多的连接。

- use

use 设置用于复用客户端线程的轮询方法。

如果你使用Linux 2.6+，你应该使用`epoll`。

如果你使用 `*BSD`，你应该使用`kqueue`。

想知道更多有关事件轮询？看下维基百科吧（注意，想了解一切的话可能需要neckbeard和操作系统的课程基础）

（值得注意的是如果你不知道Nginx该使用哪种轮询方法的话，它会选择一个最适合你操作系统的）

### 3. HTTP 模块

`HTTP模块` 控制着 `nginx http处理` 的所有核心特性。

因为这里只有很少的配置，所以我们只节选配置的一小部分。

**所有这些设置都应该在http模块中**，**即使没有特别注明**。

```nginx
http {

    server_tokens off;

    sendfile on;

    tcp_nopush on;
    tcp_nodelay on;

    ...
}
```

- server_tokens

`server_tokens` 可以 `关闭在错误页面中的nginx版本数字`，这样对于安全性是有好处的。

- sendfile

`sendfile` 可以让 `sendfile()` 发挥作用。

`sendfile()` 可以 `在磁盘和TCP socket之间互相拷贝数据(或任意两个文件描述符)`。

Pre-sendfile是传送数据之前在用户空间申请数据缓冲区。之后用 `read()` 将数据从文件拷贝到这个缓冲区，`write()` 将缓冲区数据写入网络。

`sendfile()` 是立即将数据从磁盘读到OS缓存。因为这种拷贝是在内核完成的，`sendfile()要比组合read()和write()以及打开关闭丢弃缓冲更加有效` [read more about sendfile](http://www.techrepublic.com/article/use-sendfile-to-optimize-data-transfer/)

- tcp_nopush

`tcp_nopush` 告诉nginx在一个数据包里发送所有头文件，而不一个接一个的发送.

- tcp_nodelay

`tcp_nodelay` 告诉 `nginx` 不要缓存数据，而是一段一段的发送、当需要及时发送数据时，就应该给应用设置这个属性，这样发送一小块数据信息时就不能立即得到返回值。

```nginx
access_log off;
error_log /var/log/nginx/error.log crit;
```

- access_log

`access_log` 设置nginx是否将存储访问日志。关闭这个选项可以让读取磁盘IO操作更快(aka,YOLO)
error_log 告诉nginx只能记录严重的错误

```nginx
keepalive_timeout 10;

client_header_timeout 10;
client_body_timeout 10;

reset_timedout_connection on;
send_timeout 10;
```

- keepalive_timeout

`keepalive_timeout` 给客户端分配keep-alive链接超时时间。服务器将在这个超时时间过后关闭链接。我们将它设置低些可以让ngnix持续工作的时间更长。

- client_header_timeout client_body_timeout

`client_header_timeout` 和`client_body_timeout` 设置请求头和请求体(各自)的超时时间。我们也可以把这个设置低些。

- reset_timeout_connection

`reset_timeout_connection` 告诉nginx关闭不响应的客户端连接。这将会释放那个客户端所占有的内存空间。

- send_timeout

`send_timeout` 指定客户端的响应超时时间。这个设置不会用于整个转发器，而是在两次客户端读取操作之间。如果在这段时间内，客户端没有读取任何数据，nginx就会关闭连接。

```nginx
limit_conn_zone $binary_remote_addr zone=addr:5m;
limit_conn addr 100;
```

- limit_conn_zone

`limit_conn_zone` 设置用于保存各种key（比如当前连接数）的共享内存的参数。5m就是5兆字节，这个值应该被设置的足够大以存储`（32K*5）32byte状态或者（16K*5）64byte`状态。

- limit_conn

`limit_conn` 为给定的 `key` 设置最大连接数。这里 `key` 是 `addr`，我们设置的值是100，也就是说我们允许每一个IP地址最多同时打开有100个连接。

```nginx
include /etc/nginx/mime.types;
default_type text/html;
charset UTF-8;
```

- include

`include` 只是一个在当前文件中包含另一个文件内容的指令。这里我们使用它来加载稍后会用到的一系列的MIME类型。

- default_type

`default_type` 设置文件使用的默认的 `MIME-type`。

- charset

`charset` 设置我们的头文件中的默认的字符集

```nginx
gzip on;
gzip_disable "msie6";

# gzip_static on;
gzip_proxied any;
gzip_min_length 1000;
gzip_comp_level 4;

gzip_types text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript;
```

这两个选项提供的性能改进在这个伟大的WebMaster StackExchange问​​题中得到了解释。

- gzip

`gzip` 是告诉 `nginx` 采用 `gzip压缩` 的形式发送数据。这将会减少我们发送的数据量。

- gzip_disable

`gzip_disable` 为指定的客户端禁用gzip功能。我们设置成IE6或者更低版本以使我们的方案能够广泛兼容。

- gzip_static

`gzip_static` 告诉nginx在压缩资源之前，先查找是否有预先 `gzip处理过的资源`。这要求你预先压缩你的文件（在这个例子中被注释掉了），从而允许你使用最高压缩比，这样nginx就不用再压缩这些文件了[read more about gzip_static here](http://nginx.org/en/docs/http/ngx_http_gzip_static_module.html)。

- gzip_proxied

`gzip_proxied` 允许或者禁止压缩基于请求和响应的响应流。我们设置为any，意味着将会压缩所有的请求。

- gzip_min_length

`gzip_min_length` 设置对数据启用压缩的最少字节数。如果一个请求 `小于1000字节` ，我们最好不要压缩它，因为压缩这些小的数据会降低处理此请求的所有进程的速度。

- gzip_comp_level

`gzip_comp_level` 设置数据的压缩等级。这个等级可以是1-9之间的任意数值，9是最慢但是压缩比最大的。我们设置为4，这是一个比较折中的设置。

- gzip_type

`gzip_type` 设置需要压缩的数据格式。上面例子中已经有一些了，你也可以再添加更多的格式。


```nginx
# cache informations about file descriptors, frequently accessed files
# can boost performance, but you need to test those values
open_file_cache max=100000 inactive=20s; 
open_file_cache_valid 30s; 
open_file_cache_min_uses 2;
open_file_cache_errors on;

##
# Virtual Host Configs
# aka our settings for specific servers
##

include /etc/nginx/conf.d/*.conf;
include /etc/nginx/sites-enabled/*;
```

- open_file_cache

`open_file_cache` 打开缓存的同时也指定了缓存最大数目，以及缓存的时间。我们可以设置一个相对高的最大时间，这样我们可以在它们不活动超过20秒后清除掉。

- open_file_cache_valid

`open_file_cache_valid` 在 `open_file_cache` 中指定检测正确信息的间隔时间。

- open_file_cache_min_uses

`open_file_cache_min_uses` 定义了 `open_file_cache` 中指令参数不活动时间期间里最小的文件数。

- open_file_cache_errors

`open_file_cache_errors` 指定了当搜索一个文件时是否缓存错误信息，也包括再次给配置中添加文件。我们也包括了服务器模块，这些是在不同文件中定义的。如果你的服务器模块不在这些位置，你就得修改这一行来指定正确的位置。

### 3. 一个完整的配置文件

```nginx
user www-data;
pid /var/run/nginx.pid;
worker_processes auto;
worker_rlimit_nofile 100000;

events {
    worker_connections 2048;
    multi_accept on;
    use epoll;
}

http {
    server_tokens off;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;

    access_log off;
    error_log /var/log/nginx/error.log crit;

    keepalive_timeout 10;
    client_header_timeout 10;
    client_body_timeout 10;
    reset_timedout_connection on;
    send_timeout 10;

    limit_conn_zone $binary_remote_addr zone=addr:5m;
    limit_conn addr 100;

    include /etc/nginx/mime.types;
    default_type text/html;
    charset UTF-8;

    gzip on;
    gzip_disable "msie6";
    gzip_proxied any;
    gzip_min_length 1000;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/x-javascript text/xml application/xml application/xml+rss text/javascript;

    open_file_cache max=100000 inactive=20s; 
    open_file_cache_valid 30s; 
    open_file_cache_min_uses 2;
    open_file_cache_errors on;

    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
```

## 测试！

编辑完配置后，运行下面的命令来测试配置文件的正确性。

- `nginx -t` 测试配置文件的正确性
- `nginx -s reload` 平滑重启 `nginx` 使配置文件生效。

![2019-0727-nginx-configure-learn.png](http://tc.zzutcy.top/images/2019/07/28/2019-0727-nginx-configure-learn.png)