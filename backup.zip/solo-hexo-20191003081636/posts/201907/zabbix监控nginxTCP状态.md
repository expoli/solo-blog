title: zabbix 监控 nginx、TCP 状态
date: '2019-07-30 15:47:08'
updated: '2019-08-02 18:29:15'
tags: [zabbix]
permalink: /articles/2019/07/30/1564656220810.html
---
# zabbix 监控 nginx、TCP 状态

## 0. 监控前提

1. nginx 需要整合编译 `http_stub_status_module` 模块

2. `nginx -V` 可以查看版本号和模块等信息

```bash
`nginx -V | grep with-http_stub_status_module`
```

3. 创建 `nginx` 监控页面配置文件

```nginx
server {
    listen 80;
    server_name 192.168.178.106;
   # allow 192.168.0.0/24;
   # deny all;

    location /nginx_status {
        stub_status on;
        access_log off;
    }
}
```

4. 测试、重载配置文件

```bash
nginx -t
nginx -s reload
```

5. 进行访问测试（输出如下）

![2019-07-30-watch-nginx-status-on-zabbix-0.png](http://tc.expoli.tech/images/2019/07/30/2019-07-30-watch-nginx-status-on-zabbix-0.png)

基本环境已经配置好、下面开始配置 `zabbix-agent` 来收集 `nginx` 与 `TCP` 的状态。

## 1. 开始配置

### 1. zabbix-agent 配置文件路径

```bash
/etc/zabbix/zabbix_agentd.d/
```

### 2. 创建 nginx.conf 文件

内容如下：

```bash
UserParameter=linux_status[*],/etc/zabbix/zabbix_agentd.d/zabbix_linux_plugin.sh "$1" "$2" "$3"
```

### 3. 创建脚本文件 `zabbix_linux_plugin.sh` 并赋予执行权限

```bash
vim zabbix_linux_plugin.sh
chmod +x zabbix_linux_plugin.sh
```

[zabbix_linux_plugin.sh](https://expoli.tech/zabbix_linux_plugin/)

文件里的 URL 请自行替换

```bash
nginx_active(){
        /usr/bin/curl "http://your_nginx_server_ip:"$NGINX_PORT"/nginx_status/" 2>/dev/null| grep 'Active' | awk '{print $NF}'
        }
```

![2019-07-30-watch-nginx-status-on-zabbix-1.png](http://tc.expoli.tech/images/2019/07/30/2019-07-30-watch-nginx-status-on-zabbix-1.png)

### 4. 导入 gninx 与 TCP 监控模板

你可以按照下图进行手动配置，也可以使用模板文件进行导入。

[共享地址:](https://expoli.tech/KodExplorer/index.php?share/file&user=1&sid=4uZmW29T)  提取密码:`X8Zqi`

[共享地址:](https://expoli.tech/KodExplorer/index.php?share/file&user=1&sid=MYsVe8mb)  提取密码:`B73Bn`

1. TCP

![2019-07-30-watch-nginx-status-on-zabbix-3.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-3.png)

![2019-07-30-watch-nginx-status-on-zabbix-4.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-4.png)

![2019-07-30-watch-nginx-status-on-zabbix-5.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-5.png)

2. nginx

![2019-07-30-watch-nginx-status-on-zabbix-6.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-6.png)

![2019-07-30-watch-nginx-status-on-zabbix-7.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-7.png)

![2019-07-30-watch-nginx-status-on-zabbix-8.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-8.png)

![2019-07-30-watch-nginx-status-on-zabbix-9.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-9.png)

![2019-07-30-watch-nginx-status-on-zabbix-10.png](http://tc.expoli.tech/images/2019/07/31/2019-07-30-watch-nginx-status-on-zabbix-10.png)

### 4. 重启 zabbix-agent 服务

```bash
systemctl restart zabbix-agent
netstats -ntlp
```

### 5. 测试

1. 在 zabbix-agent 主机直执行脚本

```bash
./zabbix_linux_plugin.sh nginx_status watting
```

2. 在zabbix-web上为主机添加模板

3. 访问 zabbix-web 界面查看图表信息。