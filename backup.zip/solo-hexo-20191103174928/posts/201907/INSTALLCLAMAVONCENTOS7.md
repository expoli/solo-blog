title: INSTALL CLAMAV ON CENTOS 7
date: '2019-07-27 21:47:08'
updated: '2019-08-19 19:53:34'
tags: [CentOS, ClamAV]
permalink: /articles/2019/07/27/1564656222498.html
---
# INSTALL CLAMAV ON CENTOS 7

## ClamAV 简介以及适用范围

ClamAV是一个在命令行下查毒软件，因为它不将杀毒作为主要功能，默认只能查出您计算机内的病毒，但是无法清除，至多删除文件。ClamAV可以工作很多的平台上，但是有少数无法支持，这就要取决您所使用的平台的流行程度了。另外它主要是来防护一些WINDOWS病毒和木马程序。另外，这是一个面向服务端的软件。

绝大多数的Linux是先进的，所以，很少的病毒能够在linux上运行和繁衍。而且，由于目前PC都大多数使用的是Windows，所以病毒制造者们更愿意去写Windows下的病毒。而我使用这个软件的原因是因为我想对我们实验室的网盘文件进行一次扫描，清除一些威胁文件。

下面介绍的是怎么在 Centos7 上安装并使用 `ClamAV`

## Centos7 安装 CLAMAV

VLAMAV 安装有两种方式

1. 包管理器安装（方便快捷、推荐）
2. 源码包编译安装（较为麻烦、不推荐）

### 1. 包管理器安装

```baSH
# yum install -y epel-release
# yum install -y clamav
```

### 2. 源码编译安装

官网指导文档地址：[https://www.clamav.net/documents/installation-on-redhat-and-centos-linux-distributions](https://www.clamav.net/documents/installation-on-redhat-and-centos-linux-distributions)

1. 安装依赖

- 安装开发工具组
```bash
$ sudo yum groupinstall "Development Tools"
```

- 安装库依赖项

```bash
$ sudo yum install openssl openssl-devel libcurl-devel zlib-devel libpng-devel libxml2-devel json-c-devel bzip2-devel pcre2-devel ncurses-devel
```

- (**可选项**) 如果你想使用 `clamav-milter` 则需要安装以下包 (**可选项**)

```bash
sudo yum install sendmail sendmail-devel
```

- 安装单元测试依赖项

```bash
$ sudo yum valgrind check
```

2. 下载最新稳定版的源码包

下载链接：[https://www.clamav.net/downloads](https://www.clamav.net/downloads)

3. 解压压缩包

```bash
cd ~/Downloads
tar xzf clamav-[ver].tar.gz
cd clamav-[ver].tar.gz
```

4. 运行 `Configure` 生成 `Makefile`

```bash
# 会自动检测依赖项、运行完成会打印相关摘要
./configure --enable-check
############################################################################
   configure: Summary of detected features follows
                OS          : linux-gnu
                pthreads    : yes (-lpthread)
    configure: Summary of miscellaneous features
                check       : -lcheck_pic -pthread -lrt -lm -lsubunit
                fanotify    : yes
                fdpassing   : 1
                IPv6        : yes
    configure: Summary of optional tools
                clamdtop    : -lncurses (auto)
                milter      : yes (disabled)
                clamsubmit  : yes (libjson-c-dev found at /usr), libcurl-devel found at /usr)
    configure: Summary of engine performance features
                release mode: yes
                llvm        : no (disabled)
                mempool     : yes
    configure: Summary of engine detection features
                bzip2       : ok
                zlib        : /usr
                unrar       : yes
                preclass    : yes (libjson-c-dev found at /usr)
                pcre        : /usr
                libmspack   : yes (Internal)
                libxml2     : yes, from /usr
                yara        : yes
                fts         : yes (libc)
############################################################################
```

5. 其他 ` ./configure` 选项

- `--with-systemdsystemunitdir` 
  - 不安装systemd套接字文件。此选项禁用systemd支持，但允许您在不需要 `sudo` /root权限的情况下安装到用户拥有的目录
```bash
./configure --with-systemdsystemunitdir=no
```

- `--sysconfdir` 
  - 将配置文件安装到 `/etc` 而不是 `/usr/local/etc`

```bash
./configure -–sysconfdir=/etc
```

- ` --prefix`  
  - 将ClamAV安装到 `/usr /local/`以外的目录：

```bash
# 示例1：安装到本地./install目录。
./configure --prefix=`pwd`/install
# 示例2：在非特权shell帐户上本地安装ClamAV。
./configure --prefix=$HOME/clamav --disable-clamav --with-systemdsystemunitdir=no
```
- `--disable-clamav`
  - 当作为clamav *用户运行freshclam或clamd时、不要删除超级用户权限

```bash
./configure --disable-clamav
#*提示：使用--disable-clamav意味着如果使用sudo调用，freshclam和clamd将以root权限运行。不建议以root身份运行clamd或clamscan。无需使用此选项，您可以将freshclam或clamd配置为通过以下方式把权限下放给给任何其他用户
```
- 配置 `freshclam.conf` 文件里的 `DatabaseOwner` 选项
- 配置 `clamd.conf` 文件里的 `User` 选项

6. 开始编译

```bash
make -j2
```
7. 运行 ClamAV 单元测试(可选)
```bash
make check
```
- 输出示例：

```bash
    ...
    PASS: check_clamav
    PASS: check_freshclam.sh
    PASS: check_sigtool.sh
    PASS: check_unit_vg.sh
    PASS: check1_clamscan.sh
    PASS: check2_clamd.sh
    PASS: check3_clamd.sh
    PASS: check4_clamd.sh
    PASS: check5_clamd_vg.sh
    PASS: check6_clamd_vg.sh
    SKIP: check7_clamd_hg.sh
    PASS: check8_clamd_hg.sh
    PASS: check9_clamscan_vg.sh
        ...
    ============================================================================
    Testsuite summary for ClamAV 0.100.2
    ============================================================================
    # TOTAL: 13
    # PASS:  12
    # SKIP:  1
    # XFAIL: 0
    # FAIL:  0
    # XPASS: 0
    # ERROR: 0

# 笔记：

# 除非您运行make check VG = 1，否则将跳过* .vg.sh测试。
# Check7_clamd.hg.sh（helgrind）目前已被禁用，将被跳过。
# 有关详细信息，请参阅：Git提交
# 如果您在单元测试中出现故障或错误，则可能是您缺少一个或多个依赖。
# 使用 less check4_clamd.sh.log 查看相关日志
```

8. 安装ClamAV

```bash
make install
```

9. 第一次运行前配置

修改提供的示例配置文件

- `freshclam` config

```bash
#  在使用freshclam下载更新之前，您需要创建一个freshclam配置。官方提供了一个示例配置。
cp /usr/local/etc/freshclam.conf.sample /usr/local/etc/freshclam.conf
# 将 Example行注释掉即可使用
一些其他的配置选项
可以查看文档进行详细的了解 https://www.clamav.net/documents/installation-on-redhat-and-centos-linux-distributions
# LogTime
# LogRotate
# NotifyClamd
# DatabaseOwner
```

10. 为ClamAV配置SELinux

在启用SELinux的情况下运行时，某些发行版（特别是RedHat变体）使用非标准的`antivirus_can_scan_system` SELinux选项而不是 `clamd_can_scan_system`。

此时，libclamav仅设置`clamd_can_scan_system`选项，因此您可能需要手动启用`antivirus_can_scan_system`。如果您不执行此步骤，`freshclam`将在测试新下载的签名数据库时记录类似的内容

```bash
# During database load : LibClamAV Warning: RWX mapping denied: Can't allocate RWX Memory: Permission denied
```

要允许ClamAV在SELinux下运行，请运行以下命令：

```bash
setsebool -P antivirus_can_scan_system 1
```

11. 下载/更新签名数据库

在运行扫描之前，您需要下载签名数据库。再一次，您可能需要使用 `sudo` /root权限运行。

```bash
freshclam
```

12. 用户权限配置问题

如果您以root用户或`sudo`运行`freshclam和clamd`，并且没有明确地使用`--disable-clamav` 进行配置，那么您需要确保在 `freshclam.conf` 中指定的`DatabaseOwner` 用户拥有数据库目录，以便它可以下载签名更新。

`Clamd，clamdscan和clamscan` 运行的用户可能是同一个用户，但如果不是 - 它只需要对数据库目录的读访问权限。

如果您选择使用默认的 `clamav `用户来运行 `freshclam和clamd`，则首次安装`ClamAV`时需要创建`clamav`组和`clamav`用户帐户

```bash
groupadd clamav
useradd -g clamav -s /bin/false -c "Clam Antivirus" clamav
sudo chown -R clamav:clamav /usr/local/share/clamav
```