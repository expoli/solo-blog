title: 使用 Openwrt 官方提供的 openwrt-imagebuilder 构建属于自己的 openwrt 镜像
date: '2019-03-22 18:16:08'
updated: '2019-03-22 18:16:08'
tags: [Openwrt]
permalink: /articles/2019/03/22/1564656237381.html
---
# 一、开篇介绍

因为最近在实验室瞎倒腾翻到了一个工控机，然后心心念了好久，最终还是没忍住拿来做了软路由，在折腾的过程中，遇到了很多的坑。

## 坑一

其中最大的坑莫过于自己编译属于自己的镜像了。刚开始太年轻没有相关的经验，于是就开始愣头青的交叉编译一把梭，虽然到最后是成功了，但是这个过程还是比较艰辛的，而且编译完成的镜像因为编译环境的问题，出现了与官方镜像不兼容的问题；即无法使用 `opkg` 包管理器安装官方软件包（大雾、搜索得知是自己工具链的选择有问题、在这里不禁感叹过时教程有点害人啊！！）

**所以这个方法现在不太建议大家使用**，建议大家使用下文说到的使用 `openwrt-imagebuilder` 编译自己的系统镜像。

## 坑二

官方镜像默认编译安装了下面列表里面的功能包与内核模块

```bash
Current Target: "x86 (Generic)"
Default Packages: base-files libc libgcc busybox dropbear mtd uci opkg netifd fstools uclient-fetch logd partx-utils mkf2fs e2fsprogs kmod-button-hotplug dnsmasq iptables ip6tables ppp ppp-mod-pppoe firewall odhcpd-ipv6only odhcp6c kmod-ipt-offload
Available Profiles:

Generic:
    Generic
    Packages: kmod-3c59x kmod-e100 kmod-e1000 kmod-natsemi kmod-ne2k-pci kmod-pcnet32 kmod-8139too kmod-r8169 kmod-sis900 kmod-tg3 kmod-via-rhine kmod-via-velocity
```

**敲黑板！！ 不知道大家注意到没有，官方的镜像里面是没有编译安装** `kmod-e1000e` 这个内核模块的，只有 `kmod-e1000` 这就代表如果你的软路由 **使用了千兆网卡** 这个时候如果刷入官方固件，那么很有可能，你的 `wan` 口无法正常工作，只能手动安装 `kmod-e1000e` 这个内核模块才能够正常工作。

这也是为什么我想自己编译属于自己的固件镜像的原因啦！（因为每次更新固件wan口都无法正常工作，急死人啊～～，而且更新固件的时候，还会把原来下载到软路由上 `/root` 分区的安装包给清除掉。需要手动 `scp` 上次安装（还是有点麻烦的）

# 二、方便、快捷、简单实用的 openwrt 固件镜像构建方法

在陆续踩了一堆坑了以后，后来了解到， openwrt 为每个平台、每一个版本都提供了一个 `openwrt-imagebuilder` 镜像编译环境（大雾、为什么我原来没有发现这个小可爱啊～～

下面就为大家介绍一下怎么使用 `openwrt-imagebuilder` 编译，自定义的 `x86` 平台的固件镜像。

## 1.系统环境准备

```bash
# Ubuntu 18.04.1 LTS x86_64
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install axel libncurses5-dev zlib1g-dev gawk flex patch git-core g++ subversion -y
```

## 2.下载 openwrt-imagebuilder 工具

[openwrt x86 文件下载页面](https://downloads.openwrt.org/releases/18.06.2/targets/x86/generic/)

```bash
# 40线程下载、openwrt-imagebuilder-18.06.2-x86-generic.Linux-x86_64.tar.xz 文件
axel -n 40 https://downloads.openwrt.org/releases/18.06.2/targets/x86/generic/openwrt-imagebuilder-18.06.2-x86-generic.Linux-x86_64.tar.xz
# 解压xz包
xz -d openwrt-imagebuilder-18.06.2-x86-generic.Linux-x86_64.tar.xz
# 解压tar包
tar xvf openwrt-imagebuilder-18.06.2-x86-generic.Linux-x86_64.tar 
# 进入解压文件目录
cd openwrt-imagebuilder-18.06.2-x86-generic.Linux-x86_64
```

## 3.编译环境准备

### 3.1编译命令介绍

`openwrt-imagebuilder` 的编译命令是下面这种格式

```bash
make image PROFILE=XXX PACKAGES="pkg1 pk2 -pkg3 -pkg4" FILES=files/
```

共有三个传递的参数：PROFILE PACKAGES FILES、其中

- PROFILE
  - PROFILE=XXX是指预定义的Profile，对应你的路由型号，可实用 `make info` 命令查看所有的PROFILE

```bash
# 运行 make info 后的输出
Current Target: "x86 (Generic)"
Default Packages: base-files libc libgcc busybox dropbear mtd uci opkg netifd fstools uclient-fetch logd partx-utils mkf2fs e2fsprogs kmod-button-hotplug dnsmasq iptables ip6tables ppp ppp-mod-pppoe firewall odhcpd-ipv6only odhcp6c kmod-ipt-offload
Available Profiles:

Generic:
    Generic
    Packages: kmod-3c59x kmod-e100 kmod-e1000 kmod-natsemi kmod-ne2k-pci kmod-pcnet32 kmod-8139too kmod-r8169 kmod-sis900 kmod-tg3 kmod-via-rhine kmod-via-velocity
#　这代表你所能使用的 Profile 只有 Generic 这一个
```
- PACKAGES
  - PAKAGES后面罗列出需要添加到固件中的额外的包，不填写的话只包含预定义的需要的最少的包，如果前面以”-“符号开头的表示不不含这个包，比如说：`PACKAGES=”kmod-e1000e”`
- FILES
  - 编译的时候按照所给的配置文件直接进行路由器的相关配置，各文件所在目录位置需要和路由器系统配置文件位置相对应，例如 `files/etc/config/network -> /etc/config/network`

## 4.开始编译

好了解到编译命令的各个参数的意义后，现在我们就可以开始我们的重头戏了、开始编译、构建自定义的固件镜像！

```bash
# 根据自己的需要添加自己需要的功能
# 官方已经添加了 kmod-3c59x kmod-e100 kmod-e1000 kmod-natsemi kmod-ne2k-pci kmod-pcnet32 kmod-8139too kmod-r8169 kmod-sis900 kmod-tg3 kmod-via-rhine 
# 下面是我自己的编译命令参数
make image PROFILE=Generic PACKAGES="luci luci-app-qos luci-app-upnp luci-proto-ipv6 kmod-e1000e"
# 然后等待一段时间以后就可以~\(≧▽≦)/~啦啦啦
```

### 4.1编译参数介绍

下面是我对我的编译参数的介绍、如果你有自己的特定需求的话，可以去 [openwrt 的下载界面](https://downloads.openwrt.org/releases/18.06.2/targets/x86/generic/)去`packages/`里面找到自己所需要的包的名字，然后加入到编译选项里面，进行相关定制

```bash
luci                # 网页界面
luci-sgi-uhttpd     # 默认开启utttpd，刷机后可直接网页访问luci
luci-app-qos        # QOS
luci-app-upnp       # UPNP
luci-proto-ipv6     # 向luci添加ipv6相关协议的完整支持
kmod-e1000e         # 千兆网卡支持
```