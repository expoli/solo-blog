title: rsync 工具备份客户端配置
date: '2018-11-18 19:50:08'
updated: '2018-11-18 19:50:08'
tags: [rsync, 运维]
permalink: /articles/2018/11/18/1564656235627.html
---
![image.png](./18-11-18-how-to-set-rsync-client/image.png)

# 在客户机端安装和配置rsync
<!-- more -->
## 1.安装rsync
* 如已默认安装，请卸载旧版本

```bash
$ sudo yum remove rsync -y
```

### RPM 安装

* ### RPM方式的好处，快速、方便、节时，具体安装如下：
```bash
$ yum -y install rsync
```

* ### rsync文件：

```bash
/etc/rsyncd.conf
/etc/sysconfig/rsyncd
/etc/xinetd.d/rsync
/usr/bin/rsync
/usr/share/doc/rsync-3.1.2/COPYING
......
```

## 2.配置rsync客户端 192.168.0.3

### 客户端无需配置模块，也无需启动服务，配置文件只需简单配置即可，例如：

```bash
$ sudo vim /etc/rsyncd.conf
```

```bash
uid = nobody
gid = nobody
use chroot = no
max connections = 10
pid file = /var/run/rsyncd.pid
lock file = /var/run/rsyncd.lock
log file = /var/log/rsyncd.log
port = 873
secrets file = /etc/client.pass
```

### 在客户端配置密码文件 192.168.0.3

添加密码并设置权限：
```bash
$ sudo echo "renwolecom"  >>/etc/client.pass
$ sudo chmod 600 /etc/client.pass
```

## 3.启动并加入开机自启动

```bash
$ sudo systemctl start rsyncd       # 开启
$ sudo systemctl enable rsyncd      # 开启守护进程
$ sudo systemctl list-unit-files    # 查看系统所有服务的状态
```

## 4.设置防火墙

```bash
$ sudo firewall-cmd --add-port=873/tcp --permanent
$ sudo firewall-cmd --add-port=873/udp --permanent
$ sudo firewall-cmd --reload
```

# 进行测试

## 测试rsync文件同步

### sync客户端 10.28.204.66 连接服务端测试

```bash
$ /usr/bin/rsync -avzrtopg --progress --delete --password-file=/etc/client.pass renwole@10.28.204.65::renwolecom /apps/www
```

### 客户端连接参数说明：

```bash
-avzrtopg 拆分讲解：

a # 归档模式，表示以递归方式传输文件，并保持所有文件属性，等于-rlptgoD;
v # 详细模式输出;
z # 对备份的文件在传输时进行压缩处理;
r # 对子目录以递归模式处理;
topg       # 保持原文件属性如属主、时间的参数。

--progress # 显示详细的同步进度情况。
--delete   # 若服务端端删除了这一文件，客户端也相应删除，保持文件一致。
```

### 更多参数请查看rsync帮助：

```bash
$ rsync -h
```

### 最后是问题总结

可能的报错信息：
```bash
@ERROR: auth failed on module renwole
```
此报错有两种原因导致：

1.要么在服务端配置的用户密码不正确导致。
2.要么就是服务器和客户端的密码文件不是600权限所致。

```bash
rsync: failed to connect to 10.28.204.65 (10.28.204.65): No route to host (113)
rsync error: error in socket IO (code 10) at clientserver.c(125) [Receiver=3.1.2]
```
此种无法连接到rsync服务端报错只有一种情况：

1.防火墙并未放行873端口或服务未启动，解决：关闭防火墙或放行端口即可。