title: Windows 安装 hexo + github:pages
date: '2018-10-26 12:55:08'
updated: '2018-10-26 12:55:08'
tags: [Git, Hexo]
permalink: /articles/2018/10/26/1564656234016.html
---
![image331c08ed13a2f588.png](./18-10-26-install-hexo-in-windos/image331c08ed13a2f588.png)


### 1、安装Git

<!-- more -->

下载Windows下的Git客户端并安装，安装很简单，基本一路 `Next` 下去。

### 2、安装Node.js
下载 `Node.js` ，安装 `Node.js` 也是一路 `Next` 下去。

### 3、Github配置
Github账号注册就不说了，登陆过后点击 `new repository` ，`Repository name `填写自己的名称 + `.github.io`，例如`（test.github.io，test就是你的github账号的名称）`其他的可以不用填写，也不需要改什么。

然后直接点 `Create repository` 就可以了。

### 4、配置Github SSH密钥
首先在桌面空白处鼠标右键选择 `Git Bash Here`

```bash
$ ssh-keygen -t rsa -C "your's emaill address" 
```

引号里面的内容输入你的邮箱地址，然后回车，会提示你文件保存的路径`(一般都是在自己的家目录下的 .ssh 文件夹里面)`，`windows 环境下是桌面的上级目录` 

这时候按回车键确认、然后会提示你输入密码，输入即可（输入密码是看不到的），然后会确认输入一次，`(如果个人使用的话可以不进行加密、直接留空回车就行）`

就可以在刚刚的路径看到生成了两个文件，一个是 `id_rsa` ，另一个是`id_rsa.pub` ，用 `vscode` 打开 `id_rsa.pub` 然后选中里面的全部内容，复制下来。

登录github，点击头像可以看到 `setting` 选项，点击进入,然后可以看到左边有一个 `SSH and GPG keys` 选项,点击就可以看到以下界面，点击 `New SSH`

这里的 `Title` 随便填写，主要是为了方便管理密钥、然后把刚刚拷贝的内容粘贴到 `Key` 里面去、然后点击 `Add SSH key` 、到此，Github上面的SSH配置就算完成了

### 5、创建本地仓库与Github同步
首先是在本地的任意一个分区创建一个任意的文件夹，路径中最好不要用中文吧，反正你懂的、然后进入到刚刚创建的文件夹，右键，然后点击 `Git Bash Here`、依次输入以下命令（前面的$符号就不要复制了哈）

```bash
$ git init
$ git config --global user.name "Your's name"
$ git config --global user.email "Your's email address"
```
* 其中的 `Your's name` 替换成你喜爱的名称`(我建议选择个能被别人很好识别的名字)`，`Your's email address` 替换成你的邮件地址即可,然后再当前的文件夹下面新建一个 `README.md` 文件，随便写入一点内容，做一次简单的提交，输入以下命令、其中网页链接里面的 `yourname` 是github账号的名称，每个人是不一样的.

```bash
git add README.md
git commit -m "first commit"
git remote add origin git@github.com:yourname/yourname.github.io.git
git push -u origin master
```

这时候进入到github应该就可以看到仓库下面有一个刚刚提交的README.md的文档了。

### 6、安装Hexo
在桌面空白处右键打开 `Git Bash Here`，可以先测试一下 `Node.js` 是否安装成功，直接输入`node` 可以看到提示符变成了一个向右的箭头就表示成功了，然后按`ctrl + c`退出node模式，出现`$`符号才表示正常了
输入以下命令

```
$ npm install -g hexo-cli
```
敲完回车可能没有任何提示，请一定要耐心等待、安装成功后，可以输入以下命令测试以下Hexo是否安装成功

```
$ hexo version
```
如果能看到hexo的版本号信息，就表示安装成功了、接下来，进入到我们刚刚创建的文件夹，右键打开`Git Bash Here`、然后依次输入以下命令

```bash
$ hexo init
$ npm install
$ hexo g
$ hexo s 
```

这时候在浏览器输入 `http://localhost:4000/` 就可以看到hexo已经成功生成了博客，当然这只是我们本地可以看到的

### 7、配置Hexo到Github
找到我们刚刚创建的文件夹，在里面找到 `_config.yml` 文件，找到

```
deploy:
  type:
```

改成以下，特别注意，在：的后面是有一个空格的，千万要小心，不然后出错的，其中 `yourname` 即在github上面的用户名

```
deploy:  
  type: git
  repository: https://github.com/yourname/yourname.github.io.git
  branch: master
```

如果你是在其他平台上搭建的自己的博客，可以照看下面的进行配置

```bash
deploy:
  type: git
  repo: git@zzutcy.top:yourepo.git
```

保存后，然后在当前文件夹打开`Git Bash Here`

```
$ hexo clean
$ hexo g
$ hexo d
```

如果出现以下异常 `ERROR Deployer not found: git`,尝试输入以下命令，然后重新执行刚刚的两条命令

```bash
$ npm install hexo-deployer-git --save
```

这时候如果弹出一个对话框，输入在github上面的用户名和密码即可、这时候我们就可以在浏览器输入`https://yourname.github.io`（yourname替换成github上的名称）就可以看到博客已经搭建成功了。

[转载自->简书 4Four](https://www.jianshu.com/p/956c44c87fb1)