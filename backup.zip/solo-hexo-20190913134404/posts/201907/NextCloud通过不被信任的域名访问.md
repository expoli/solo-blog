title: NextCloud 通过不被信任的域名访问
date: '2019-07-29 22:47:08'
updated: '2019-08-19 19:50:47'
tags: [Nextcloud]
permalink: /articles/2019/07/29/1564656219723.html
---
# NextCloud 通过不被信任的域名访问

## 问题出现的原因

前几天、将我的私人云盘 `nextcloud` 的解析域名更换了一下、结果发现网站报错：`NextCloud 通过不被信任的域名访问` 具体情况如下图所示

![image2018-10-22_10-54-39.pngversion1modificationDate1540177098000apiv2.png](http://tc.expoli.tech/images/2019/07/29/image2018-10-22_10-54-39.pngversion1modificationDate1540177098000apiv2.png)

## 问题原因

经过一番搜索发现、出现这个问题的原因是 `Nextcloud` 的一个保护机制、即只能通过信任的域名进行访问，域名配置文件为 `/path/to/your/web/root/dir/config/config.php` 具体配置如下图：

![2019-07-29-NextCloud-.png](http://tc.expoli.tech/images/2019/07/29/2019-07-29-NextCloud-.png)

## 解决方案

域名配置项在 23 ~ 16 行之间，将你需要填写的域名进行相应替换就可。