title: 安装 Centos 7 时刚引导成功、就报 python3 错误的解决方案
date: '2018-04-20 08:34:26'
updated: '2018-04-20 08:34:26'
tags: [坑]
permalink: /articles/2018/04/20/1564656224983.html
---
![18-04-20--install-system-to-server0](./18-04-20-install-system-on-server/18-04-20--install-system-to-server0.jpg)

## 安装 Centos 7 时刚引导成功、就报 python3 错误的解决方案
<!-- more -->

因为第一次接触服务器，所以不太清楚服务器的机器的特性，看到机器预装的是win server 2008、又看到机器说明书上所说支持 CentOS 于是，就准备给机子换个“身体”，给他装上Linux！

于是经过一番漫长的下载镜像，写入镜像（U盘不是很争气、写入速度比较慢

漫长的等待。。。。

终于！！！ 进入了安装界面！！ 激动人心的时刻到来了。

满怀期待地的按下 确定安装 

突然！！！ WTF error

```bash
python3 error -*******
# 错误代码已经记不清了
```

？？？？  黑人问号 ？？？？？？

经过一番排查，最终发现是 `分区表问题` 原来的分区表格式是 `MBR 格式` `Centos7` 默认需要的是 `GPT 格式`。

在更改过分区表格式之后、安装过程很顺利。