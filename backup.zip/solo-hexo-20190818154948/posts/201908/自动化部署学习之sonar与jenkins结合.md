title: 自动化部署学习之——sonar 与 jenkins 结合
date: '2019-08-18 14:43:51'
updated: '2019-08-18 15:28:36'
tags: [运维, Sonar, Jenkins]
permalink: /articles/2019/08/18/1566110631575.html
---
![](https://img.hacpai.com/bing/20171227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# jenkins实战——sonar与jenkins结合

## 1. 环境要求

### 1.1 SonarQube 与 Jenkins安装并启动完成

## 2. 设置 Jenkins

### 1.1 修改系统设置

添加 Sonar server

![7-jenkinssonarjenkins0.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins0.png)

### 1.2 全局工具配置

### 1.3 添加 SonarQube Scanner

![7-jenkinssonarjenkins1.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins1.png)

## 3. 重新配置 Jenkins 项目

### 3.1 在项目配置项的 build 栏目中添加构建参数

![7-jenkinssonarjenkins2.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins2.png)

### 3.2 进行立即构建测试

### 3.3 查看构建结果以及 Sonar 报表

## 3. 设置构建完成后的动作

### 3.1 发送邮件

### 3.2 执行一个shell脚本

1. 遇到权限问题、可以将 Jenkins 用户加入到 soduers 文件内部、以便于执行 sudo 

```bash
jenkins ALL=(ALL) NOPASSWD: /usr/bin/ssh
```

2. 遇到 使用 sudo 需要一个 tty 的时候可以将 /etc/sudoers 的注释掉

```bash
Defaults requiretyy
```

## 4. 添加构建后动作

### 4.1 构建完成后开始构建另一项工程

![7-jenkinssonarjenkins3.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins3.png)

## 5. 安装构建流水线插件 Build Pipeline

### 5.1 新建 buid-pipeline 视图

![7-jenkinssonarjenkins4.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins4.png)

![7-jenkinssonarjenkins5.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins5.png)

### 5.2 配置相关信息

![7-jenkinssonarjenkins6.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins6.png)

### 5.3 查看效果

查看 pipeline 视图、可以很直观的看出构建的流程、同时也可以很方便的打开控制台、查看输出便于排错。

![7-jenkinssonarjenkins7.png](http://tc.zzutcy.top/images/2019/08/18/7-jenkinssonarjenkins7.png)
